-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 05, 2023 at 05:46 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bmsdata`
--

-- --------------------------------------------------------

--
-- Table structure for table `householddata`
--

CREATE TABLE `householddata` (
  `house#` varchar(60) NOT NULL,
  `purok` varchar(60) NOT NULL,
  `street` varchar(60) NOT NULL,
  `members` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `householddata`
--

INSERT INTO `householddata` (`house#`, `purok`, `street`, `members`) VALUES
('625', 'Tramo North', 'Sto. Cristo', '3');

-- --------------------------------------------------------

--
-- Table structure for table `officialsandstaff`
--

CREATE TABLE `officialsandstaff` (
  `id` int(60) NOT NULL,
  `position` varchar(60) NOT NULL,
  `name` varchar(60) NOT NULL,
  `contact` varchar(60) NOT NULL,
  `address` varchar(60) NOT NULL,
  `startofterm` varchar(60) NOT NULL,
  `endofterm` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `officialsandstaff`
--

INSERT INTO `officialsandstaff` (`id`, `position`, `name`, `contact`, `address`, `startofterm`, `endofterm`) VALUES
(4, 'Kapitan', 'Ariel Labuson', '09451570794', '625 Tramo Santo Cristo', '2022-05-14', '2028-05-14'),
(5, 'Kagawad', 'emmanuel', '09123456789', '625 Tramo Santo Cristo', '2022-05-14', '2028-05-14'),
(6, 'Kapitan', 'Juan Dela Cruz', '01234567891', '625 Tramo Santo Cristo', '2022-05-14', '2028-05-14'),
(7, 'kagawad', 'joana dela cruz', '01234567891', '625 Tramo Santo Cristo', '2022-05-14', '2028-05-14');

-- --------------------------------------------------------

--
-- Table structure for table `requestrecord`
--

CREATE TABLE `requestrecord` (
  `id#` varchar(60) NOT NULL,
  `name` varchar(60) NOT NULL,
  `cnumber` varchar(60) NOT NULL,
  `address` varchar(60) NOT NULL,
  `requestpaper` varchar(60) NOT NULL,
  `purpose` varchar(60) NOT NULL,
  `requeststatus` varchar(60) NOT NULL,
  `assistancerequest` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `requestrecord`
--

INSERT INTO `requestrecord` (`id#`, `name`, `cnumber`, `address`, `requestpaper`, `purpose`, `requeststatus`, `assistancerequest`) VALUES
('20230001', 'ARIEL GALLARDO LABUSON', '09451570794', '625 TRAMO NORTH STO. CRISTO', 'Certificate of Indigency', 'for my work', 'pending', 'Medical Assistance'),
('20230002', 'EMMANUEL GALLARDO LABUSON', '09238445254', '625 TRAMO NORTH STO. CRISTO', 'barangay clearance', 'for my work', 'pending', 'Burial Assistance');

-- --------------------------------------------------------

--
-- Table structure for table `residentsdata`
--

CREATE TABLE `residentsdata` (
  `id` varchar(60) NOT NULL,
  `name` varchar(60) NOT NULL,
  `contact` varchar(60) NOT NULL,
  `address` varchar(60) NOT NULL,
  `birthdate` varchar(60) NOT NULL,
  `sex` varchar(60) NOT NULL,
  `conditionstatus` varchar(60) NOT NULL,
  `civilstatus` varchar(60) NOT NULL,
  `voterstatus` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `residentsdata`
--

INSERT INTO `residentsdata` (`id`, `name`, `contact`, `address`, `birthdate`, `sex`, `conditionstatus`, `civilstatus`, `voterstatus`) VALUES
('20230001', 'ARIEL GALLARDO LABUSON', '09451570794', '625 TRAMO NORTH STO. CRISTO', 'January 31 1999', 'Male', 'PWD', 'Single', 'yes');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `officialsandstaff`
--
ALTER TABLE `officialsandstaff`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `officialsandstaff`
--
ALTER TABLE `officialsandstaff`
  MODIFY `id` int(60) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
