-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 16, 2023 at 06:41 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bmsdata`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcementrecord`
--

CREATE TABLE `announcementrecord` (
  `id` int(60) NOT NULL,
  `date` varchar(60) NOT NULL,
  `subject` varchar(60) NOT NULL,
  `body` varchar(1000) NOT NULL,
  `admin` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcementrecord`
--

INSERT INTO `announcementrecord` (`id`, `date`, `subject`, `body`, `admin`) VALUES
(17, 'February-16-2023', 'Barangay announcement', 'Tell your goodnight to the light and close your eyes\r\nThere\'s a better place for you than to stay awake\r\nYou\'ll get closer to a paradise of dreamers in love\r\nYou\'ll get better like heaven has done something\r\nSo lay now, I\'ll take over the night\r\nThere\'s no teardrop, you can count on me tonight\r\nOr I\'ll stay up with you\r\nBaby, it\'s alright, I\'ll be right by your side\r\nNo need to cry out loud, nothing to cry about\r\nBaby, it\'s alright, I\'ll be just by your side\r\nI\'ll keep you on my sight, I\'ll never leave \'til you sleep tonight\r\nI\'ll cover you with my arms and hold you tight, oh, I\'ll\r\nI\'ll be listening to your wonderful and calm little voice\r\nI\'ll keep watching \'til my eyes burn down\r\nBaby, it\'s alright, I\'ll be right by your side\r\nNo need to cry out loud, nothing to cry about\r\nBaby, it\'s alright, I\'ll be just by your side\r\nI\'ll keep you on my sight, I\'ll never leave \'til you sleep tonight\r\nI\'ll never sleep, I\'ll never leave\r\nI\'m gonna chase this dream tonight\r\nI\'ll never leave, I\'ll nev', 'Sto. Cristo Management'),
(18, 'February-16-2023', 'Barangay announcement', 'Tell your goodnight to the light and close your eyes\r\nThere\'s a better place for you than to stay awake\r\nYou\'ll get closer to a paradise of dreamers in love\r\nYou\'ll get better like heaven has done something\r\nSo lay now, I\'ll take over the night\r\nThere\'s no teardrop, you can count on me tonight\r\nOr I\'ll stay up with you\r\nBaby, it\'s alright, I\'ll be right by your side\r\nNo need to cry out loud, nothing to cry about\r\nBaby, it\'s alright, I\'ll be just by your side\r\nI\'ll keep you on my sight, I\'ll never leave \'til you sleep tonight\r\nI\'ll cover you with my arms and hold you tight, oh, I\'ll\r\nI\'ll be listening to your wonderful and calm little voice\r\nI\'ll keep watching \'til my eyes burn down\r\nBaby, it\'s alright, I\'ll be right by your side\r\nNo need to cry out loud, nothing to cry about\r\nBaby, it\'s alright, I\'ll be just by your side\r\nI\'ll keep you on my sight, I\'ll never leave \'til you sleep tonight\r\nI\'ll never sleep, I\'ll never leave\r\nI\'m gonna chase this dream tonight\r\nI\'ll never leave, I\'ll nev', 'Sto. Cristo Management'),
(19, 'February-16-2023', 'Barangay announcement', 'Tell your goodnight to the light and close your eyes\r\nThere\'s a better place for you than to stay awake\r\nYou\'ll get closer to a paradise of dreamers in love\r\nYou\'ll get better like heaven has done something\r\nSo lay now, I\'ll take over the night\r\nThere\'s no teardrop, you can count on me tonight\r\nOr I\'ll stay up with you\r\nBaby, it\'s alright, I\'ll be right by your side\r\nNo need to cry out loud, nothing to cry about\r\nBaby, it\'s alright, I\'ll be just by your side\r\nI\'ll keep you on my sight, I\'ll never leave \'til you sleep tonight\r\nI\'ll cover you with my arms and hold you tight, oh, I\'ll\r\nI\'ll be listening to your wonderful and calm little voice\r\nI\'ll keep watching \'til my eyes burn down\r\nBaby, it\'s alright, I\'ll be right by your side\r\nNo need to cry out loud, nothing to cry about\r\nBaby, it\'s alright, I\'ll be just by your side\r\nI\'ll keep you on my sight, I\'ll never leave \'til you sleep tonight\r\nI\'ll never sleep, I\'ll never leave\r\nI\'m gonna chase this dream tonight\r\nI\'ll never leave, I\'ll nev', 'Sto. Cristo Management'),
(20, 'February-16-2023', 'Barangay announcement', 'Tell your goodnight to the light and close your eyes\r\nThere\'s a better place for you than to stay awake\r\nYou\'ll get closer to a paradise of dreamers in love\r\nYou\'ll get better like heaven has done something\r\nSo lay now, I\'ll take over the night\r\nThere\'s no teardrop, you can count on me tonight\r\nOr I\'ll stay up with you\r\nBaby, it\'s alright, I\'ll be right by your side\r\nNo need to cry out loud, nothing to cry about\r\nBaby, it\'s alright, I\'ll be just by your side\r\nI\'ll keep you on my sight, I\'ll never leave \'til you sleep tonight\r\nI\'ll cover you with my arms and hold you tight, oh, I\'ll\r\nI\'ll be listening to your wonderful and calm little voice\r\nI\'ll keep watching \'til my eyes burn down\r\nBaby, it\'s alright, I\'ll be right by your side\r\nNo need to cry out loud, nothing to cry about\r\nBaby, it\'s alright, I\'ll be just by your side\r\nI\'ll keep you on my sight, I\'ll never leave \'til you sleep tonight\r\nI\'ll never sleep, I\'ll never leave\r\nI\'m gonna chase this dream tonight\r\nI\'ll never leave, I\'ll nev', 'Sto. Cristo Management');

-- --------------------------------------------------------

--
-- Table structure for table `approvedrequestrecord`
--

CREATE TABLE `approvedrequestrecord` (
  `id#` varchar(60) NOT NULL,
  `name` varchar(60) NOT NULL,
  `cnumber` varchar(60) NOT NULL,
  `address` varchar(60) NOT NULL,
  `requestpaper` varchar(60) NOT NULL,
  `purpose` varchar(60) NOT NULL,
  `requeststatus` varchar(60) NOT NULL,
  `assistancerequest` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `blotterrecord`
--

CREATE TABLE `blotterrecord` (
  `complainant` varchar(60) NOT NULL,
  `address` varchar(60) NOT NULL,
  `age` varchar(60) NOT NULL,
  `contact` varchar(60) NOT NULL,
  `complainanee` varchar(60) NOT NULL,
  `address1` varchar(60) NOT NULL,
  `age1` varchar(60) NOT NULL,
  `contact1` varchar(60) NOT NULL,
  `complaint` varchar(60) NOT NULL,
  `status` varchar(60) NOT NULL,
  `action` varchar(60) NOT NULL,
  `incidence` varchar(60) NOT NULL,
  `date` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blotterrecord`
--

INSERT INTO `blotterrecord` (`complainant`, `address`, `age`, `contact`, `complainanee`, `address1`, `age1`, `contact1`, `complaint`, `status`, `action`, `incidence`, `date`) VALUES
('juan dela cruz', '625 tramo', '23', '09451570794', 'juana dela cruz', '625 tramo', '39', '09123456789', 'sample', 'Unsolve', '1st Option', 'tramo', 'February-16-2023');

-- --------------------------------------------------------

--
-- Table structure for table `declinedrequestrecord`
--

CREATE TABLE `declinedrequestrecord` (
  `id#` varchar(60) NOT NULL,
  `name` varchar(60) NOT NULL,
  `cnumber` varchar(60) NOT NULL,
  `address` varchar(60) NOT NULL,
  `requestpaper` varchar(60) NOT NULL,
  `purpose` varchar(60) NOT NULL,
  `requeststatus` varchar(60) NOT NULL,
  `assistancerequest` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `historyrecrod`
--

CREATE TABLE `historyrecrod` (
  `name` varchar(60) NOT NULL,
  `requestpaper` varchar(60) NOT NULL,
  `date` varchar(60) NOT NULL,
  `id#` varchar(60) NOT NULL,
  `queue` int(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `historyrecrod`
--

INSERT INTO `historyrecrod` (`name`, `requestpaper`, `date`, `id#`, `queue`) VALUES
('ariel gallardo labuson', 'Barangay Clearance', 'February-16-2023', '20236345', 5),
('ariel gallardo labuson', 'Business Clearance', 'February-16-2023', '20236345', 6),
('ariel gallardo labuson', 'Certification', 'February-16-2023', '20236345', 7),
('ariel gallardo labuson', 'Barangay Indigency', 'February-16-2023', '20236345', 8);

-- --------------------------------------------------------

--
-- Table structure for table `householddata`
--

CREATE TABLE `householddata` (
  `house#` varchar(60) NOT NULL,
  `purok` varchar(60) NOT NULL,
  `street` varchar(60) NOT NULL,
  `members` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `householddata`
--

INSERT INTO `householddata` (`house#`, `purok`, `street`, `members`) VALUES
('625', 'Tramo North', 'Sto. Cristo', '3');

-- --------------------------------------------------------

--
-- Table structure for table `officialsandstaff`
--

CREATE TABLE `officialsandstaff` (
  `id` int(60) NOT NULL,
  `position` varchar(60) NOT NULL,
  `name` varchar(60) NOT NULL,
  `contact` varchar(60) NOT NULL,
  `address` varchar(60) NOT NULL,
  `startofterm` varchar(60) NOT NULL,
  `endofterm` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `officialsandstaff`
--

INSERT INTO `officialsandstaff` (`id`, `position`, `name`, `contact`, `address`, `startofterm`, `endofterm`) VALUES
(4, 'Kapitan', 'Ariel Labuson', '09451570794', '625 Tramo Santo Cristo', '2022-05-14', '2028-05-14'),
(5, 'Kagawad', 'emmanuel', '09123456789', '625 Tramo Santo Cristo', '2022-05-14', '2028-05-14'),
(6, 'Kapitan', 'Juan Dela Cruz', '01234567891', '625 Tramo Santo Cristo', '2022-05-14', '2028-05-14'),
(7, 'kagawad', 'joana dela cruz', '01234567891', '625 Tramo Santo Cristo', '2022-05-14', '2028-05-14');

-- --------------------------------------------------------

--
-- Table structure for table `requestrecord`
--

CREATE TABLE `requestrecord` (
  `id#` varchar(60) NOT NULL,
  `name` varchar(60) NOT NULL,
  `cnumber` varchar(60) NOT NULL,
  `address` varchar(60) NOT NULL,
  `requestpaper` varchar(60) NOT NULL,
  `purpose` varchar(60) NOT NULL,
  `requeststatus` varchar(60) NOT NULL,
  `assistancerequest` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `requestrecord`
--

INSERT INTO `requestrecord` (`id#`, `name`, `cnumber`, `address`, `requestpaper`, `purpose`, `requeststatus`, `assistancerequest`) VALUES
('20236345', 'ariel gallardo labuson', '09451570794', '625 Tramo  Santo Cristo', 'Barangay Clearance', 'sample', 'Pending', ''),
('20236345', 'ariel gallardo labuson', '09451570794', '625 Tramo  Santo Cristo', 'Business Clearance', 'sample2', 'Pending', ''),
('20236345', 'ariel gallardo labuson', '09451570794', '625 Tramo  Santo Cristo', 'Certification', 'sample3', 'Pending', ''),
('20236345', 'ariel gallardo labuson', '09451570794', '625 Tramo  Santo Cristo', 'Certificate of Indigency', 'sample4', 'Pending', 'Medical Assistance');

-- --------------------------------------------------------

--
-- Table structure for table `residentsdata`
--

CREATE TABLE `residentsdata` (
  `id` varchar(60) NOT NULL,
  `name` varchar(60) NOT NULL,
  `contact` varchar(60) NOT NULL,
  `address` varchar(60) NOT NULL,
  `birthdate` varchar(60) NOT NULL,
  `sex` varchar(60) NOT NULL,
  `conditionstatus` varchar(60) NOT NULL,
  `civilstatus` varchar(60) NOT NULL,
  `voterstatus` varchar(60) NOT NULL,
  `username` varchar(60) NOT NULL,
  `password` varchar(60) NOT NULL,
  `loginattempt` int(11) NOT NULL,
  `email` varchar(60) NOT NULL,
  `qrcode` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `residentsdata`
--

INSERT INTO `residentsdata` (`id`, `name`, `contact`, `address`, `birthdate`, `sex`, `conditionstatus`, `civilstatus`, `voterstatus`, `username`, `password`, `loginattempt`, `email`, `qrcode`) VALUES
('20236345', 'ariel gallardo labuson', '09451570794', '625 Tramo  Santo Cristo', 'january 31, 1999', 'Male', 'PWD', 'Single', 'YES', '20236345', '0043112b802dd5bc9a3c1419c10978f0', 1, 'ariellabuson08@gmail.com', '752b615e10ee40bad9f0fcc9b7a07e2f'),
('20234754', ' irwin  payaoan batoy', '09451570794', '625   Tramo Santo Cristo', 'january 1, 1940', 'Male', 'Normal', 'Single', 'YES', '20234754', '0043112b802dd5bc9a3c1419c10978f0', 1, 'ariellabuson08@gmail.com', '720f2aa1673beac1cede7c393a294ea0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcementrecord`
--
ALTER TABLE `announcementrecord`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `historyrecrod`
--
ALTER TABLE `historyrecrod`
  ADD PRIMARY KEY (`queue`);

--
-- Indexes for table `officialsandstaff`
--
ALTER TABLE `officialsandstaff`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcementrecord`
--
ALTER TABLE `announcementrecord`
  MODIFY `id` int(60) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `historyrecrod`
--
ALTER TABLE `historyrecrod`
  MODIFY `queue` int(60) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `officialsandstaff`
--
ALTER TABLE `officialsandstaff`
  MODIFY `id` int(60) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
